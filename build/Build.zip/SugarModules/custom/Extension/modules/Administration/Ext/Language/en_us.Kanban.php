<?php
$mod_strings['LBL_KANBAN_TITLE'] = 'Kanban Board Settings';
$mod_strings['LBL_KANBAN_DESC'] = 'Configuring modules that use the kanban board';

$mod_strings['LBL_KANBAN_SETTINGS'] = 'Configuring Modules for which a kanban board is available';
$mod_strings['LBL_KANBAN_SETTINGS_DESCRIPTION'] = 'Configuring Modules for which a kanban board is available';