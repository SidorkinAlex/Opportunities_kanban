<?php
$app_list_strings['kanban_board']['LBL_BUTTON_MENU'] = 'Kanban board';