# Opportunities Kanban board from SuiteCRM

[Github](https://github.com/SidorkinAlex/Opportunities_kanban) | 

### License

Is published under the AGPLv3 license.




