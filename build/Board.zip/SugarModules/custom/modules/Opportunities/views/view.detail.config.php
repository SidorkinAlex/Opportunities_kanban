<?php
/**
 * Created by PhpStorm.
 * User: seedteam
 * Date: 26.08.20
 * Time: 16:14
 */
$view_config['actions']['quickdetail'] = array(
    'show_header' => false,
    'show_footer' => false,
    'view_print' => false,
    'show_title' => false,
    'show_subpanels' => true,
    'show_javascript' => true,
    'show_search' => true,
    'json_output' => false,
);
