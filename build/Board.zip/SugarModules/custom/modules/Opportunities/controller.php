<?php
/**
 * Created by PhpStorm.
 * User: seedteam
 * Date: 26.08.20
 * Time: 16:01
 */
class CustomOpportunitiesController extends SugarController
{
     public function action_quickDetail(){
         $this->view = 'detail';
     }

}